package com.onetoone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringonetoonemappingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringonetoonemappingApplication.class, args);
		System.out.println("Application is Running.......");
	}

}
